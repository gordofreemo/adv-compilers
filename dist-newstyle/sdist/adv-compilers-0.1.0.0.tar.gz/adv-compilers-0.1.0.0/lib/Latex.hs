module Latex where

class LatexShow tau where
  latexShow :: tau -> String


